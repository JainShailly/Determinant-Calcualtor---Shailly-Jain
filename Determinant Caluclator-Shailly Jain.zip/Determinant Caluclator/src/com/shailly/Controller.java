package com.shailly;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;


public class Controller {

    @FXML
    public TabPane pane ;

    // Text fields for 2x2 matrix
    @FXML
    public TextField order2_00, order2_01;
    @FXML
    public TextField order2_10, order2_11;

    //Text fields for 3x3 matrix
    @FXML
    public TextField order3_00, order3_01, order3_02;
    @FXML
    public TextField order3_10, order3_11, order3_12;
    @FXML
    public TextField order3_20, order3_21, order3_22;

    //Text fields for 4x4 matrix
    @FXML
    public TextField order4_00, order4_01, order4_02, order4_03;
    @FXML
    public TextField order4_10, order4_11, order4_12, order4_13;
    @FXML
    public TextField order4_20, order4_21, order4_22, order4_23;
    @FXML
    public TextField order4_30, order4_31, order4_32, order4_33;


    //Text fields for 5x5 matrix
    @FXML
    public TextField order5_00, order5_01, order5_02, order5_03, order5_04;
    @FXML
    public TextField order5_10, order5_11, order5_12, order5_13, order5_14;
    @FXML
    public TextField order5_20, order5_21, order5_22, order5_23, order5_24;
    @FXML
    public TextField order5_30, order5_31, order5_32, order5_33, order5_34;
    @FXML
    public TextField order5_40, order5_41, order5_42, order5_43, order5_44;

    @FXML
    public void handleEvaluateButton(){
        int selectedIndex = pane.getSelectionModel().getSelectedIndex();

        double result = 0.0;
        boolean isValid = true;
        double[][] data;


        switch(selectedIndex){


            case 0:
                data = new double[2][2];
                try{
                    data[0][0] = Double.parseDouble(order2_00.getText());
                    data[0][1] = Double.parseDouble(order2_01.getText());

                    data[1][0] = Double.parseDouble(order2_10.getText());
                    data[1][1] = Double.parseDouble(order2_11.getText());
                    result = detOrder2(data);
                }catch(Exception e){
                    isValid = false;
                }
                break;

            case 1:
                data = new double[3][3];
                try{
                    data[0][0] = Double.parseDouble(order3_00.getText());
                    data[0][1] = Double.parseDouble(order3_01.getText());
                    data[0][2] = Double.parseDouble(order3_02.getText());

                    data[1][0] = Double.parseDouble(order3_10.getText());
                    data[1][1] = Double.parseDouble(order3_11.getText());
                    data[1][2] = Double.parseDouble(order3_12.getText());

                    data[2][0] = Double.parseDouble(order3_20.getText());
                    data[2][1] = Double.parseDouble(order3_21.getText());
                    data[2][2] = Double.parseDouble(order3_22.getText());

                    result = detOrder3(data);
                }catch(Exception e){
                    isValid = false;
                }
                break;

            case 2:
                data = new double[4][4];
                try{
                    data[0][0] = Double.parseDouble(order4_00.getText());
                    data[0][1] = Double.parseDouble(order4_01.getText());
                    data[0][2] = Double.parseDouble(order4_02.getText());
                    data[0][3] = Double.parseDouble(order4_03.getText());

                    data[1][0] = Double.parseDouble(order4_10.getText());
                    data[1][1] = Double.parseDouble(order4_11.getText());
                    data[1][2] = Double.parseDouble(order4_12.getText());
                    data[1][3] = Double.parseDouble(order4_13.getText());

                    data[2][0] = Double.parseDouble(order4_20.getText());
                    data[2][1] = Double.parseDouble(order4_21.getText());
                    data[2][2] = Double.parseDouble(order4_22.getText());
                    data[2][3] = Double.parseDouble(order4_23.getText());

                    data[3][0] = Double.parseDouble(order4_30.getText());
                    data[3][1] = Double.parseDouble(order4_31.getText());
                    data[3][2] = Double.parseDouble(order4_32.getText());
                    data[3][3] = Double.parseDouble(order4_33.getText());

                    result = detOrder4(data);
                }catch(Exception e){
                    isValid = false;
                }
                break;

            case 3:
                data = new double[5][5];
                try{
                    data[0][0] = Double.parseDouble(order5_00.getText());
                    data[0][1] = Double.parseDouble(order5_01.getText());
                    data[0][2] = Double.parseDouble(order5_02.getText());
                    data[0][3] = Double.parseDouble(order5_03.getText());
                    data[0][4] = Double.parseDouble(order5_04.getText());

                    data[1][0] = Double.parseDouble(order5_10.getText());
                    data[1][1] = Double.parseDouble(order5_11.getText());
                    data[1][2] = Double.parseDouble(order5_12.getText());
                    data[1][3] = Double.parseDouble(order5_13.getText());
                    data[1][4] = Double.parseDouble(order5_14.getText());

                    data[2][0] = Double.parseDouble(order5_20.getText());
                    data[2][1] = Double.parseDouble(order5_21.getText());
                    data[2][2] = Double.parseDouble(order5_22.getText());
                    data[2][3] = Double.parseDouble(order5_23.getText());
                    data[2][4] = Double.parseDouble(order5_24.getText());

                    data[3][0] = Double.parseDouble(order5_30.getText());
                    data[3][1] = Double.parseDouble(order5_31.getText());
                    data[3][2] = Double.parseDouble(order5_32.getText());
                    data[3][3] = Double.parseDouble(order5_33.getText());
                    data[3][4] = Double.parseDouble(order5_34.getText());

                    data[4][0] = Double.parseDouble(order5_40.getText());
                    data[4][1] = Double.parseDouble(order5_41.getText());
                    data[4][2] = Double.parseDouble(order5_42.getText());
                    data[4][3] = Double.parseDouble(order5_43.getText());
                    data[4][4] = Double.parseDouble(order5_44.getText());

                    result = detOrder5(data);
                }catch(Exception e){
                    isValid = false;
                }
                break;
        }
        if(isValid){
            showAlert(Alert.AlertType.INFORMATION, "Result : " + result, "Result");
        }else{
            showAlert(Alert.AlertType.ERROR, "Invalid data","Syntax Error" );
        }
    }

    public void showAlert(Alert.AlertType type, String message, String title){
        Alert alert = new Alert(type);
        alert.setContentText(message);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.showAndWait();
    }

    double detOrder2(double[][] data){
        // returns the determinant of a 2x2 matrix
        return (data[0][0]*data[1][1] - data[0][1]*data[1][0]);
    }

    double detOrder3(double[][] data){
        // returns the determinant of a 3x3 matrix
        double det = 0.0;

        double[][] subDeterminant = new double[2][2];

        subDeterminant[0][0] = data[1][1];
        subDeterminant[0][1] = data[1][2];
        subDeterminant[1][0] = data[2][1];
        subDeterminant[1][1] = data[2][2];

        det += data[0][0]*detOrder2(subDeterminant);

        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][2];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][2];

        det -= data[0][1]*detOrder2(subDeterminant);

        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][1];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][1];

        det += data[0][2]*detOrder2(subDeterminant);

        return det;

    }

    double detOrder4(double[][] data){
        // returns the determinant of a 4x4 matrix
        double det = 0.0;

        double[][] subDeterminant = new double[3][3];

        subDeterminant[0][0] = data[1][1];
        subDeterminant[0][1] = data[1][2];
        subDeterminant[0][2] = data[1][3];
        subDeterminant[1][0] = data[2][1];
        subDeterminant[1][1] = data[2][2];
        subDeterminant[1][2] = data[2][3];
        subDeterminant[2][0] = data[3][1];
        subDeterminant[2][1] = data[3][2];
        subDeterminant[2][2] = data[3][3];

        det += data[0][0]*detOrder3(subDeterminant);

        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][2];
        subDeterminant[0][2] = data[1][3];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][2];
        subDeterminant[1][2] = data[2][3];
        subDeterminant[2][0] = data[3][0];
        subDeterminant[2][1] = data[3][2];
        subDeterminant[2][2] = data[3][3];

        det -= data[0][1]*detOrder3(subDeterminant);

        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][1];
        subDeterminant[0][2] = data[1][3];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][1];
        subDeterminant[1][2] = data[2][3];
        subDeterminant[2][0] = data[3][0];
        subDeterminant[2][1] = data[3][1];
        subDeterminant[2][2] = data[3][3];

        det += data[0][2]*detOrder3(subDeterminant);

        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][1];
        subDeterminant[0][2] = data[1][2];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][1];
        subDeterminant[1][2] = data[2][2];
        subDeterminant[2][0] = data[3][0];
        subDeterminant[2][1] = data[3][1];
        subDeterminant[2][2] = data[3][2];

        det -= data[0][3]*detOrder3(subDeterminant);

        return det;

    }

    double detOrder5(double[][] data){
        // returns the determinant of a 5x5 matrix
        double det = 0.0;

        double[][] subDeterminant = new double[4][4];

        subDeterminant[0][0] = data[1][1];
        subDeterminant[0][1] = data[1][2];
        subDeterminant[0][2] = data[1][3];
        subDeterminant[0][3] = data[1][4];
        subDeterminant[1][0] = data[2][1];
        subDeterminant[1][1] = data[2][2];
        subDeterminant[1][2] = data[2][3];
        subDeterminant[1][3] = data[2][4];
        subDeterminant[2][0] = data[3][1];
        subDeterminant[2][1] = data[3][2];
        subDeterminant[2][2] = data[3][3];
        subDeterminant[2][3] = data[3][4];
        subDeterminant[3][0] = data[4][1];
        subDeterminant[3][1] = data[4][2];
        subDeterminant[3][2] = data[4][3];
        subDeterminant[3][3] = data[4][4];

        det += data[0][0]*detOrder4(subDeterminant);


        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][2];
        subDeterminant[0][2] = data[1][3];
        subDeterminant[0][3] = data[1][4];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][2];
        subDeterminant[1][2] = data[2][3];
        subDeterminant[1][3] = data[2][4];
        subDeterminant[2][0] = data[3][0];
        subDeterminant[2][1] = data[3][2];
        subDeterminant[2][2] = data[3][3];
        subDeterminant[2][3] = data[3][4];
        subDeterminant[3][0] = data[4][0];
        subDeterminant[3][1] = data[4][2];
        subDeterminant[3][2] = data[4][3];
        subDeterminant[3][3] = data[4][4];

        det -= data[0][1]*detOrder4(subDeterminant);

        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][1];
        subDeterminant[0][2] = data[1][3];
        subDeterminant[0][3] = data[1][4];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][1];
        subDeterminant[1][2] = data[2][3];
        subDeterminant[1][3] = data[2][4];
        subDeterminant[2][0] = data[3][0];
        subDeterminant[2][1] = data[3][1];
        subDeterminant[2][2] = data[3][3];
        subDeterminant[2][3] = data[3][4];
        subDeterminant[3][0] = data[4][0];
        subDeterminant[3][1] = data[4][1];
        subDeterminant[3][2] = data[4][3];
        subDeterminant[3][3] = data[4][4];

        det += data[0][2]*detOrder4(subDeterminant);

        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][1];
        subDeterminant[0][2] = data[1][2];
        subDeterminant[0][3] = data[1][4];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][1];
        subDeterminant[1][2] = data[2][2];
        subDeterminant[1][3] = data[2][4];
        subDeterminant[2][0] = data[3][0];
        subDeterminant[2][1] = data[3][1];
        subDeterminant[2][2] = data[3][2];
        subDeterminant[2][3] = data[3][4];
        subDeterminant[3][0] = data[4][0];
        subDeterminant[3][1] = data[4][1];
        subDeterminant[3][2] = data[4][2];
        subDeterminant[3][3] = data[4][4];

        det -= data[0][3]*detOrder4(subDeterminant);

        subDeterminant[0][0] = data[1][0];
        subDeterminant[0][1] = data[1][1];
        subDeterminant[0][2] = data[1][2];
        subDeterminant[0][3] = data[1][3];
        subDeterminant[1][0] = data[2][0];
        subDeterminant[1][1] = data[2][1];
        subDeterminant[1][2] = data[2][2];
        subDeterminant[1][3] = data[2][3];
        subDeterminant[2][0] = data[3][0];
        subDeterminant[2][1] = data[3][1];
        subDeterminant[2][2] = data[3][2];
        subDeterminant[2][3] = data[3][3];
        subDeterminant[3][0] = data[4][0];
        subDeterminant[3][1] = data[4][1];
        subDeterminant[3][2] = data[4][2];
        subDeterminant[3][3] = data[4][3];

        det += data[0][4]*detOrder4(subDeterminant);

        return det;
    }

}
